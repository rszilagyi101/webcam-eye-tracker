import sys
from pathlib import Path

# Make `import app` / `import eye_tracker` work when pytest runs from anywhere.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
