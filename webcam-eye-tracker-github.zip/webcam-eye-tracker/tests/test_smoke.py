"""Hermetic smoke tests: no webcam, no network, no display required."""
import io
import sys
import zipfile

import numpy as np
import pandas as pd
import pytest

import app as webapp
import eye_tracker as et

SW, SH = 1920, 1080


# ----------------------------------------------------------------- core maths

def test_calibration_recovers_screen_centre():
    samples = []
    for nx, ny in et.CALIBRATION_POINTS_NORM:
        # pretend the iris ratio moves linearly with where you look
        samples.append((0.2 + 0.6 * nx, 0.2 + 0.6 * ny, nx * SW, ny * SH))
    coeffs = et.fit_calibration(samples)
    x, y = et.apply_calibration(coeffs, 0.5, 0.5, SW, SH)
    assert x == pytest.approx(SW / 2, abs=1)
    assert y == pytest.approx(SH / 2, abs=1)


def test_apply_calibration_clamps_to_screen():
    coeffs = et.fit_calibration(
        [(0.2 + 0.6 * nx, 0.2 + 0.6 * ny, nx * SW, ny * SH) for nx, ny in et.CALIBRATION_POINTS_NORM]
    )
    x, y = et.apply_calibration(coeffs, 5.0, -5.0, SW, SH)
    assert 0 <= x <= SW - 1 and 0 <= y <= SH - 1


def test_naive_map_centre():
    x, y = et.naive_map(0.5, 0.5, SW, SH)
    assert (x, y) == (pytest.approx(SW / 2, abs=1), pytest.approx(SH / 2, abs=1))


def _session_df(with_mouse=False, n=300):
    rng = np.random.default_rng(0)
    df = pd.DataFrame({
        "timestamp_s": np.linspace(0, 30, n),
        "screen_x": np.clip(rng.normal(SW * 0.5, 200, n), 0, SW - 1),
        "screen_y": np.clip(rng.normal(SH * 0.5, 150, n), 0, SH - 1),
        "h_ratio": rng.normal(0.5, 0.1, n),
        "v_ratio": rng.normal(0.5, 0.1, n),
        "face_found": True,
    })
    if with_mouse:
        df["mouse_x"] = np.clip(rng.normal(SW * 0.3, 100, n), 0, SW - 1)
        df["mouse_y"] = np.clip(rng.normal(SH * 0.7, 100, n), 0, SH - 1)
    return df


def test_heatmap_shape_and_content():
    img = et.build_heatmap(_session_df(), SW, SH)
    assert img.shape == (SH, SW, 3) and img.dtype == np.uint8
    assert img.max() > 30  # something was drawn on top of the dark background


def test_heatmap_with_no_valid_points_does_not_crash():
    df = _session_df()
    df["screen_x"] = np.nan
    df["screen_y"] = np.nan
    assert et.build_heatmap(df, SW, SH).shape == (SH, SW, 3)


def test_comparison_heatmap():
    img = et.build_comparison_heatmap(_session_df(with_mouse=True), SW, SH)
    assert img.shape == (SH, SW, 3)


def test_csv_roundtrip(tmp_path):
    df = _session_df(with_mouse=True)
    path = tmp_path / "s.csv"
    et.save_session_csv(df, path)
    back = pd.read_csv(path)
    assert list(back.columns) == list(df.columns)
    assert len(back) == len(df)


def test_screen_size_and_screenshot_never_raise():
    w, h = et.get_screen_size()
    assert w > 0 and h > 0
    shot = et.grab_screenshot(w, h)  # None on a headless CI box is fine
    assert shot is None or shot.shape == (h, w, 3)


def test_mouse_reader_degrades_gracefully():
    msgs = []
    reader = et._make_mouse_reader(progress_cb=lambda p, m: msgs.append(m))
    # Headless CI: None (+ a message). Desktop: a callable returning floats.
    assert reader is None or callable(reader)
    if reader is None:
        assert msgs


# ------------------------------------------------------------------ web app

@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.setattr(webapp, "DATA_DIR", tmp_path)
    webapp._set_state(
        mode="idle", error=None, last_csv=None, last_heatmap=None,
        last_mouse_heatmap=None, last_comparison=None,
    )
    return webapp.app.test_client()


def test_index_page(client):
    r = client.get("/")
    assert r.status_code == 200
    for text in (b"Start Tracking", b"Run Calibration", b"Also track mouse pointer", b"Quit app"):
        assert text in r.data
    assert client.get("/static/style.css").status_code == 200


def test_status_endpoint(client):
    body = client.get("/api/status").get_json()
    assert body["mode"] == "idle"


def test_track_parameters_are_validated(client, monkeypatch):
    started = []
    monkeypatch.setattr(webapp, "_tracking_job", lambda *a: started.append(a))
    r = client.post("/api/track", json={
        "duration_s": 99999, "delay_s": -3, "open_url": "example.com", "track_mouse": True,
    })
    body = r.get_json()
    assert r.status_code == 200
    assert body["duration_s"] == 600.0          # clamped to 10 min
    assert body["delay_s"] == 0.0               # clamped to >= 0
    assert body["open_url"] == "https://example.com"
    assert body["track_mouse"] is True


def test_second_job_is_rejected_while_busy(client):
    webapp._set_state(mode="starting")
    assert client.post("/api/track", json={}).status_code == 409
    assert client.post("/api/calibrate").status_code == 409


def test_download_all_without_session_is_404(client):
    assert client.get("/download_all").status_code == 404


def test_download_all_zips_the_session(client, tmp_path):
    stamp = "20260101_120000"
    names = {
        "last_csv": f"session_{stamp}.csv",
        "last_heatmap": f"heatmap_{stamp}.png",
        "last_mouse_heatmap": f"mouse_heatmap_{stamp}.png",
        "last_comparison": f"comparison_{stamp}.png",
    }
    for n in names.values():
        (tmp_path / n).write_bytes(b"data-" + n.encode())
    webapp._set_state(mode="done", **names)

    r = client.get("/download_all")
    assert r.status_code == 200
    assert f"eye_tracking_{stamp}.zip" in r.headers["Content-Disposition"]
    zf = zipfile.ZipFile(io.BytesIO(r.data))
    assert sorted(zf.namelist()) == sorted(names.values())


def test_quit_blocked_while_busy_and_works_when_idle(client, monkeypatch):
    fired = []

    class FakeTimer:  # never actually kill the test process
        def __init__(self, interval, fn):
            fired.append(interval)

        def start(self):
            pass

    monkeypatch.setattr(webapp.threading, "Timer", FakeTimer)
    webapp._set_state(mode="tracking")
    assert client.post("/api/quit").status_code == 409
    assert fired == []
    webapp._set_state(mode="idle")
    assert client.post("/api/quit").get_json()["ok"] is True
    assert len(fired) == 1


def test_find_free_port_skips_5000():
    port = webapp._find_free_port()
    assert port != 5000 and 1024 < port < 65535


# ------------------------------------------- calibration runs in a subprocess

@pytest.mark.parametrize("code,mode,calibrated", [
    (0, "idle", True),     # saved
    (2, "idle", False),    # cancelled with ESC
    (1, "error", False),   # crashed
])
def test_calibration_subprocess_outcomes(monkeypatch, code, mode, calibrated):
    monkeypatch.setattr(
        webapp, "_calibration_command",
        lambda: [sys.executable, "-c", f"import sys; print('child output'); sys.exit({code})"],
    )
    webapp._set_state(calibrated=False, error=None)
    webapp._calibration_job()
    s = webapp._get_state()
    assert s["mode"] == mode
    assert s["calibrated"] is calibrated
    if mode == "error":
        assert "child output" in s["error"]
